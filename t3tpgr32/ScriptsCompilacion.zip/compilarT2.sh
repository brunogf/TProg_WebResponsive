cd t2tpgr32/t2tpgr32
ant
cd build/web
jar -cvf ../../../../t2tpgr32.war *
 
