cd tpgr32/tpgr32
ant
cd build/classes
jar -cvfm ../../../../tpgr32.jar ../../manifesto.mf tpgr32 Servidor Interfaz META-INF
cp -avr lib ../../../../
cp -avr ../../Imagenes ../../../../
cd ../../../../
chmod a+x tpgr32.jar




