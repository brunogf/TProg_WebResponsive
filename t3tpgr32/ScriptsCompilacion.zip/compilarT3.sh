cd t3tpgr32/t3tpgr32
ant
cd build/web
jar -cvf ../../../../t3tpgr32.war *
 
