sh compilarT1.sh
sh compilarT2.sh
sh compilarT3.sh
 
